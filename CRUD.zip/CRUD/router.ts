import express from 'express'
import Controller from "./controller";

const app = express()
app.use(express.json())

app.post('/posts', Controller.create)
app.get('/posts', Controller.getAll)
app.get('/posts/:id', Controller.getOne)
app.put('/posts/:id', Controller.update)
app.delete('/posts/:id', Controller.delete)

export default app;
