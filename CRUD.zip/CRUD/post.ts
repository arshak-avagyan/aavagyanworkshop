let posts = [
    {
        id: 1,
        carName: 'Porsche',
        carModel: 'Panamera',
        carColor: 'White'
    },
    {
        id: 2,
        carName: 'Audi',
        carModel: 'A7',
        carColor: 'Red'
    },
    {
        id: 3,
        carName: 'BMW',
        carModel: 'M5',
        carColor: 'Black'
    },
]

export default posts
