import express from 'express'
import app from "./router";

const PORT = 5000;

app.use(express.json())

function startApp() {
    try {
        app.listen(PORT, () => console.log(`SERVER STARTED ON PORT ${PORT}`))
    } catch (e) {
        console.log(e)
    }
}

startApp()
