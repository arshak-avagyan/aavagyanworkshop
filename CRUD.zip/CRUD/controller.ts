import { error } from "console";
import posts from "./post";

class Controller {
    async create(req: any, res: any) {
        try {
            const post = {
                id: posts.length + 2,
                carName: req.body.carName,
                carModel: req.body.carModel,
                carColor: req.body.carColor
            };
            posts.push(post)
            res.send(post)
        } catch (e) {
            res.status(500).json(e)
        }
    }

    async getAll(req: any, res: any) {
        try {
            res.send(posts)
        } catch (e) {
            res.status(500).json(e)
        }
    }

    async getOne(req: any, res: any) {
        try {
            const post = posts.find(post => post.id === parseInt(req.params.id))
            res.send(post)
        } catch (e) {
            res.status(500).json(e)
        }
    }

    async update(req :any, res: any) {
        try {
            let post = posts.find(post => post.id === parseInt(req.params.id)) 
            if(!post) throw error;
            post.carName = req.body.carName || post.carName,
            post.carModel = req.body.carModel || post.carModel,
            post. carColor = req.body.carColor || post.carColor  
            res.send(posts)
        } catch (e) {
            res.status(500).json(e)
        }
    }
    async delete(req: any, res: any) {
        try {
            let post = posts.find(post => post.id === parseInt(req.params.id)) 
            if(!post) throw error;
            posts.splice(posts.indexOf(post),1)
            res.send(posts)
        } catch (e) {
            res.status(500).json(e)
        }
    }
}


export default new Controller();
