import express from 'express';
import { filename, outputPath, PORT } from '../Config/config';
import { readByLine, writeByLine } from '../Controller/controller';

const app = express()

app.get('/readstream', (req: any, res: any) => {
    res.send(`Reading from ${filename}`)
    readByLine()
});

app.get('/writestream', (req: any, res: any) => {
    res.send(`Writing to ${outputPath}`)
    writeByLine()
});

app.listen(PORT, () => console.log('Server is running'))



