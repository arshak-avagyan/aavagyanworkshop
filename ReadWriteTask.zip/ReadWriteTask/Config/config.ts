import path from 'path';

const filename = path.join(__dirname, '..', 'Data', 'text.txt')
const outputPath = path.join(__dirname, '..', 'Output', 'data.json')
const PORT = 3000;

export {filename, outputPath, PORT}