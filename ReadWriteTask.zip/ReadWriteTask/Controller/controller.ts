import fs from 'fs';
import readline from 'readline';
import os from 'os';
import {filename, outputPath} from '../Config/config';


async function readByLine() {
    const readStream = fs.createReadStream(filename, {encoding: 'utf-8'})
    const rl = readline.createInterface({
        input: readStream,
        crlfDelay: Infinity
    });

    for await (let line of rl) {
        console.log(line)
    }
};

async function writeByLine() {
    const readStream = fs.createReadStream(filename, {encoding: 'utf-8'})
    const writeStream = fs.createWriteStream(outputPath, {encoding: "utf8"});
    const rl = readline.createInterface({
        input: readStream,
        crlfDelay: Infinity,
    });

    rl.on('line', (line) => {
        writeStream.write(line + os.EOL)
    });
};

export {readByLine, writeByLine}